## 1.0.2
###### Core:
  - Added Primo Core platform
  - Added DFU service in all Primo and Primo Core sketches
  
###### Libraries:
  - Added CoreSensor library

###### Misc:
  - Added bootloader files
  
## 1.0.1
###### Core:
  - Fixed Tone issue if no duration was indicate

###### Libraries:
  - Added BAT library
  - Modified CIR library
  - Fixed pins initialization in Wire library
  
###### Misc:
  - Added CHANGELOG.md
  - Updated drivers for Windows
  - Updated STM32 firmware

## 1.0.0 - 2017-04-21
First release